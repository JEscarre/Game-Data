# Game Data · Training Data v3

Aquesta actualització està preparada **sobre el repositori original `JEscarre/Game-Data`**.

## Què preserva

- Login original: la pantalla només demana la contrasenya; `VITE_LOGIN_EMAIL` continua intern.
- Disseny original (`src/styles.css` no es reemplaça).
- Estructura i dades existents de `games`, `game_players` i `game_events`.
- Flux de partit, marcador, substitucions, temps morts, cronologia i desfer.

## Què afegeix

- Pas del rellotge manual de 30 en 30 segons.
- Comptador de faltes més gran i més llegible, mantenint el codi visual 1–5.
- Secció nova `Entrenaments` al header.
- Plantilla persistent només per Training Data, amb data d'alta i baixa.
- Importació de jugadors des de l'últim partit.
- Assistència per entrenament i percentatge acumulat. Un fitxatge nou només computa des de la seva data d'alta.
- Competicions `Shooting`, `Free throws` i `Competition`, amb múltiples competicions de cada tipus per entrenament.
- Empats per posició: qualsevol nombre de jugadors pot compartir 1r, 2n, 3r o 4t.
- Punts: 1r=4, 2n=3, 3r=2, 4t=1.
- Classificació acumulada per categoria i total de temporada.
- Exportació `.xlsx` amb Resum temporada, Assistència, Competicions, Resultats i Entrenaments.

## Instal·lació més fàcil en Mac

Descomprimeix aquest ZIP i, des de la carpeta descomprimida:

```bash
chmod +x prepare_from_github_mac.sh
./prepare_from_github_mac.sh
```

Això crea una carpeta completa a:

```text
~/Desktop/Game-Data-v3
```

a partir del GitHub original i aplica l'actualització sense substituir fitxers originals que no cal tocar, inclòs el logo.

Després copia el teu `.env.local` anterior a `Game-Data-v3/.env.local` o crea'l des de `.env.example`.

## Supabase

Executa **una sola vegada**:

```text
supabase/migration_training_v3.sql
```

No tornis a executar `schema.sql` ni `migration_v2.sql` si la versió actual ja funciona.

## Prova local

```bash
cd ~/Desktop/Game-Data-v3
npm run dev
```

L'original està configurat per obrir-se a `http://localhost:3000`.

## Nota sobre el càlcul final

El rànquing de temporada d'aquesta versió suma literalment els punts 4–3–2–1 especificats per a totes les competicions i mostra els totals separats de Shooting, Free throws i Competition. L'assistència es mostra com una mètrica pròpia i no afegeix punts de competició.
