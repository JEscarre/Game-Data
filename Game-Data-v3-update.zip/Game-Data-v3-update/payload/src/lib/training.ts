import type {
  CompetitionResult,
  CompetitionType,
  PlayerTrainingSummary,
  TrainingAttendance,
  TrainingCompetition,
  TrainingPlayer,
  TrainingSession,
} from '../types'

export const pointsForPlace = (place: number) => ({ 1: 4, 2: 3, 3: 2, 4: 1 }[place] ?? 0)

export const competitionTypeLabel: Record<CompetitionType, string> = {
  shooting: 'Shooting',
  free_throws: 'Free throws',
  competition: 'Competition',
}

export const isPlayerEligibleForDate = (player: TrainingPlayer, date: string) =>
  player.joined_on <= date && (!player.left_on || player.left_on >= date)

export function buildTrainingSummary(
  players: TrainingPlayer[],
  sessions: TrainingSession[],
  attendance: TrainingAttendance[],
  competitions: TrainingCompetition[],
  results: CompetitionResult[],
): PlayerTrainingSummary[] {
  const competitionById = new Map(competitions.map((competition) => [competition.id, competition]))

  const rows = players.map((player) => {
    const eligibleSessions = sessions.filter((session) => isPlayerEligibleForDate(player, session.session_date))
    const eligibleIds = new Set(eligibleSessions.map((session) => session.id))
    const present = attendance.filter(
      (item) => item.player_id === player.id && item.present && eligibleIds.has(item.session_id),
    ).length

    const points: Record<CompetitionType, number> = {
      shooting: 0,
      free_throws: 0,
      competition: 0,
    }

    results
      .filter((result) => result.player_id === player.id)
      .forEach((result) => {
        const competition = competitionById.get(result.competition_id)
        if (competition) points[competition.competition_type] += result.points
      })

    return {
      player,
      sessions: eligibleSessions.length,
      present,
      attendancePct: eligibleSessions.length ? (present / eligibleSessions.length) * 100 : 0,
      shooting: points.shooting,
      freeThrows: points.free_throws,
      competition: points.competition,
      totalPoints: points.shooting + points.free_throws + points.competition,
      finalRank: 0,
    }
  })

  const sorted = [...rows].sort((a, b) => b.totalPoints - a.totalPoints || a.player.name.localeCompare(b.player.name))
  let previousPoints: number | null = null
  let rank = 0
  sorted.forEach((row, index) => {
    if (previousPoints !== row.totalPoints) rank = index + 1
    row.finalRank = rank
    previousPoints = row.totalPoints
  })

  const rankById = new Map(sorted.map((row) => [row.player.id, row.finalRank]))
  return rows.map((row) => ({ ...row, finalRank: rankById.get(row.player.id) ?? 0 }))
}
