import * as XLSX from 'xlsx'
import type {
  CompetitionResult,
  PlayerTrainingSummary,
  TrainingAttendance,
  TrainingCompetition,
  TrainingPlayer,
  TrainingSession,
} from '../types'
import { competitionTypeLabel, isPlayerEligibleForDate } from './training'

export function exportTrainingExcel(args: {
  players: TrainingPlayer[]
  sessions: TrainingSession[]
  attendance: TrainingAttendance[]
  competitions: TrainingCompetition[]
  results: CompetitionResult[]
  summary: PlayerTrainingSummary[]
}) {
  const { players, sessions, attendance, competitions, results, summary } = args
  const workbook = XLSX.utils.book_new()
  const playerById = new Map(players.map((player) => [player.id, player]))
  const sessionById = new Map(sessions.map((session) => [session.id, session]))
  const competitionById = new Map(competitions.map((competition) => [competition.id, competition]))
  const orderedSessions = [...sessions].sort((a, b) => a.session_date.localeCompare(b.session_date))

  const summaryRows = [...summary]
    .sort((a, b) => a.finalRank - b.finalRank || a.player.name.localeCompare(b.player.name))
    .map((row) => ({
      Posició: row.finalRank,
      Jugador: row.player.name,
      Dorsal: row.player.jersey_number,
      'Data alta': row.player.joined_on,
      'Entrenaments computables': row.sessions,
      Assistències: row.present,
      '% assistència': row.attendancePct / 100,
      Shooting: row.shooting,
      'Free throws': row.freeThrows,
      Competition: row.competition,
      'Punts totals': row.totalPoints,
    }))

  const summarySheet = XLSX.utils.json_to_sheet(summaryRows)
  summarySheet['!cols'] = [8, 24, 8, 12, 21, 13, 14, 11, 13, 13, 12].map((wch) => ({ wch }))
  for (let row = 2; row <= summaryRows.length + 1; row += 1) {
    if (summarySheet[`G${row}`]) summarySheet[`G${row}`].z = '0.0%'
  }
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resum temporada')

  const attendanceRows = players.map((player) => {
    const row: Record<string, string | number> = {
      Jugador: player.name,
      Dorsal: player.jersey_number,
      'Data alta': player.joined_on,
    }
    for (const session of orderedSessions) {
      if (!isPlayerEligibleForDate(player, session.session_date)) {
        row[session.session_date] = ''
        continue
      }
      const item = attendance.find((entry) => entry.session_id === session.id && entry.player_id === player.id)
      row[session.session_date] = item?.present ? 1 : 0
    }
    const aggregate = summary.find((item) => item.player.id === player.id)
    row.Total = aggregate?.present ?? 0
    row['% assistència'] = (aggregate?.attendancePct ?? 0) / 100
    return row
  })

  const attendanceSheet = XLSX.utils.json_to_sheet(attendanceRows)
  attendanceSheet['!cols'] = [
    { wch: 24 }, { wch: 8 }, { wch: 12 },
    ...orderedSessions.map(() => ({ wch: 12 })),
    { wch: 10 }, { wch: 14 },
  ]
  const attendancePctColumn = XLSX.utils.encode_col(3 + orderedSessions.length + 1)
  for (let row = 2; row <= attendanceRows.length + 1; row += 1) {
    if (attendanceSheet[`${attendancePctColumn}${row}`]) attendanceSheet[`${attendancePctColumn}${row}`].z = '0.0%'
  }
  XLSX.utils.book_append_sheet(workbook, attendanceSheet, 'Assistència')

  const competitionRows = [...competitions]
    .sort((a, b) => {
      const dateA = sessionById.get(a.session_id)?.session_date ?? ''
      const dateB = sessionById.get(b.session_id)?.session_date ?? ''
      return dateA.localeCompare(dateB) || a.sequence_no - b.sequence_no
    })
    .map((competition) => ({
      Data: sessionById.get(competition.session_id)?.session_date ?? '',
      Entrenament: sessionById.get(competition.session_id)?.title ?? '',
      Tipus: competitionTypeLabel[competition.competition_type],
      Competició: competition.name,
      Número: competition.sequence_no,
    }))
  const competitionSheet = XLSX.utils.json_to_sheet(competitionRows)
  competitionSheet['!cols'] = [{ wch: 12 }, { wch: 24 }, { wch: 16 }, { wch: 28 }, { wch: 8 }]
  XLSX.utils.book_append_sheet(workbook, competitionSheet, 'Competicions')

  const resultRows = results
    .map((result) => {
      const competition = competitionById.get(result.competition_id)
      const session = competition ? sessionById.get(competition.session_id) : undefined
      return {
        Data: session?.session_date ?? '',
        Entrenament: session?.title ?? '',
        Tipus: competition ? competitionTypeLabel[competition.competition_type] : '',
        Competició: competition?.name ?? '',
        Jugador: playerById.get(result.player_id)?.name ?? '',
        Posició: result.place,
        Punts: result.points,
      }
    })
    .sort((a, b) => a.Data.localeCompare(b.Data) || a.Competició.localeCompare(b.Competició) || a.Posició - b.Posició)
  const resultsSheet = XLSX.utils.json_to_sheet(resultRows)
  resultsSheet['!cols'] = [{ wch: 12 }, { wch: 22 }, { wch: 16 }, { wch: 28 }, { wch: 24 }, { wch: 9 }, { wch: 8 }]
  XLSX.utils.book_append_sheet(workbook, resultsSheet, 'Resultats')

  const sessionRows = orderedSessions.map((session) => ({
    Data: session.session_date,
    Entrenament: session.title,
    Notes: session.notes ?? '',
    Assistents: attendance.filter((item) => item.session_id === session.id && item.present).length,
    Competicions: competitions.filter((competition) => competition.session_id === session.id).length,
  }))
  const sessionsSheet = XLSX.utils.json_to_sheet(sessionRows)
  sessionsSheet['!cols'] = [{ wch: 12 }, { wch: 24 }, { wch: 45 }, { wch: 12 }, { wch: 14 }]
  XLSX.utils.book_append_sheet(workbook, sessionsSheet, 'Entrenaments')

  XLSX.writeFile(workbook, `kidsus-training-data-${new Date().toISOString().slice(0, 10)}.xlsx`)
}
