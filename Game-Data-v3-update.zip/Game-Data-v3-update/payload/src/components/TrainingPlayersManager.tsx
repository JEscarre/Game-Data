import { FormEvent, useState } from 'react'
import { supabase } from '../lib/supabase'
import type { GamePlayer, TrainingPlayer } from '../types'

interface Props {
  players: TrainingPlayer[]
  onChange: () => Promise<void>
}

export function TrainingPlayersManager({ players, onChange }: Props) {
  const [name, setName] = useState('')
  const [number, setNumber] = useState('')
  const [joinedOn, setJoinedOn] = useState(new Date().toISOString().slice(0, 10))
  const [busy, setBusy] = useState(false)

  const addPlayer = async (event: FormEvent) => {
    event.preventDefault()
    if (!name.trim()) return
    setBusy(true)
    const { error } = await supabase.from('training_players').insert({
      name: name.trim(),
      jersey_number: number.trim(),
      joined_on: joinedOn,
      active: true,
      left_on: null,
    })
    setBusy(false)
    if (error) return alert(error.message)
    setName('')
    setNumber('')
    await onChange()
  }

  const togglePlayer = async (player: TrainingPlayer) => {
    const nextActive = !player.active
    const { error } = await supabase
      .from('training_players')
      .update({ active: nextActive, left_on: nextActive ? null : new Date().toISOString().slice(0, 10) })
      .eq('id', player.id)
    if (error) return alert(error.message)
    await onChange()
  }

  const updateJoinedOn = async (player: TrainingPlayer, joined_on: string) => {
    if (!joined_on) return
    const { error } = await supabase.from('training_players').update({ joined_on }).eq('id', player.id)
    if (error) return alert(error.message)
    await onChange()
  }

  const importLatestGame = async () => {
    setBusy(true)
    const { data: games, error: gamesError } = await supabase
      .from('games')
      .select('id,game_date')
      .order('game_date', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(1)
    if (gamesError) {
      setBusy(false)
      return alert(gamesError.message)
    }
    const game = games?.[0]
    if (!game) {
      setBusy(false)
      return alert('No hi ha cap partit del qual importar jugadors.')
    }

    const { data, error } = await supabase
      .from('game_players')
      .select('*')
      .eq('game_id', game.id)
      .eq('side', 'home')
      .order('sort_order')
    if (error) {
      setBusy(false)
      return alert(error.message)
    }

    const rows = ((data ?? []) as GamePlayer[]).map((player) => ({
      name: player.name,
      jersey_number: player.jersey_number,
      joined_on: new Date().toISOString().slice(0, 10),
      active: true,
      left_on: null,
    }))

    if (rows.length) {
      const { error: insertError } = await supabase
        .from('training_players')
        .upsert(rows, { onConflict: 'name', ignoreDuplicates: true })
      if (insertError) {
        setBusy(false)
        return alert(insertError.message)
      }
    }
    setBusy(false)
    await onChange()
  }

  return (
    <section className="card training-card">
      <div className="section-heading training-section-heading">
        <div>
          <p className="eyebrow">PLANTILLA D'ENTRENAMENT</p>
          <h2>Jugadors</h2>
        </div>
        <button className="button secondary compact" onClick={importLatestGame} disabled={busy}>Importar últim partit</button>
      </div>

      <form className="training-player-form" onSubmit={addPlayer}>
        <input placeholder="Nom del jugador" value={name} onChange={(event) => setName(event.target.value)} required />
        <input placeholder="Dorsal" value={number} onChange={(event) => setNumber(event.target.value)} />
        <label className="training-date-field"><span>Alta</span><input type="date" value={joinedOn} onChange={(event) => setJoinedOn(event.target.value)} /></label>
        <button className="button primary" disabled={busy}>Afegir jugador</button>
      </form>

      <div className="training-roster-list">
        {players.map((player) => (
          <div className={`training-roster-row ${player.active ? '' : 'inactive'}`} key={player.id}>
            <span className="jersey">{player.jersey_number || '–'}</span>
            <div className="training-roster-copy">
              <strong>{player.name}</strong>
              <small>{player.active ? 'Actiu' : `Baixa ${player.left_on ?? ''}`}</small>
            </div>
            <label className="training-joined-inline"><span>Compta des de</span><input type="date" value={player.joined_on} onChange={(event) => void updateJoinedOn(player, event.target.value)} /></label>
            <button className="button secondary compact" onClick={() => void togglePlayer(player)}>{player.active ? 'Donar de baixa' : 'Reactivar'}</button>
          </div>
        ))}
        {!players.length && <p className="empty-inline">Encara no hi ha jugadors. Els pots afegir o importar de l'últim partit.</p>}
      </div>
    </section>
  )
}
