import { FormEvent, useEffect, useMemo, useState } from 'react'
import { exportTrainingExcel } from '../lib/exportTrainingExcel'
import { supabase } from '../lib/supabase'
import { buildTrainingSummary, competitionTypeLabel, isPlayerEligibleForDate, pointsForPlace } from '../lib/training'
import type {
  CompetitionResult,
  CompetitionType,
  TrainingAttendance,
  TrainingCompetition,
  TrainingPlayer,
  TrainingSession,
} from '../types'
import { TrainingPlayersManager } from './TrainingPlayersManager'

type View = 'season' | 'sessions' | 'players'

export function TrainingDashboard() {
  const [view, setView] = useState<View>('season')
  const [players, setPlayers] = useState<TrainingPlayer[]>([])
  const [sessions, setSessions] = useState<TrainingSession[]>([])
  const [attendance, setAttendance] = useState<TrainingAttendance[]>([])
  const [competitions, setCompetitions] = useState<TrainingCompetition[]>([])
  const [results, setResults] = useState<CompetitionResult[]>([])
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')

  const loadTraining = async () => {
    setLoading(true)
    setLoadError('')
    const [playersResult, sessionsResult, attendanceResult, competitionsResult, resultsResult] = await Promise.all([
      supabase.from('training_players').select('*').order('active', { ascending: false }).order('name'),
      supabase.from('training_sessions').select('*').order('session_date', { ascending: false }).order('created_at', { ascending: false }),
      supabase.from('training_attendance').select('*'),
      supabase.from('training_competitions').select('*'),
      supabase.from('training_competition_results').select('*'),
    ])

    const firstError = playersResult.error || sessionsResult.error || attendanceResult.error || competitionsResult.error || resultsResult.error
    if (firstError) {
      setLoadError(firstError.message)
      setLoading(false)
      return
    }

    setPlayers((playersResult.data ?? []) as TrainingPlayer[])
    setSessions((sessionsResult.data ?? []) as TrainingSession[])
    setAttendance((attendanceResult.data ?? []) as TrainingAttendance[])
    setCompetitions((competitionsResult.data ?? []) as TrainingCompetition[])
    setResults((resultsResult.data ?? []) as CompetitionResult[])
    setLoading(false)
  }

  useEffect(() => {
    void loadTraining()
    const channel = supabase
      .channel('training-data')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'training_players' }, () => void loadTraining())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'training_sessions' }, () => void loadTraining())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'training_attendance' }, () => void loadTraining())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'training_competitions' }, () => void loadTraining())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'training_competition_results' }, () => void loadTraining())
      .subscribe()

    return () => {
      void supabase.removeChannel(channel)
    }
  }, [])

  const summary = useMemo(
    () => buildTrainingSummary(players, sessions, attendance, competitions, results),
    [players, sessions, attendance, competitions, results],
  )
  const selectedSession = sessions.find((session) => session.id === selectedSessionId) ?? null

  if (loadError) {
    return (
      <main className="page-shell training-shell">
        <section className="card training-error-card">
          <p className="eyebrow">TRAINING DATA</p>
          <h1>Falta preparar Supabase</h1>
          <p>No s'han pogut carregar les taules d'entrenaments.</p>
          <code>{loadError}</code>
          <p>Executa una sola vegada <strong>supabase/migration_training_v3.sql</strong> a l'SQL Editor del projecte actual.</p>
          <button className="button secondary" onClick={() => void loadTraining()}>Tornar-ho a provar</button>
        </section>
      </main>
    )
  }

  if (selectedSession) {
    return (
      <TrainingSessionEditor
        session={selectedSession}
        players={players.filter((player) => isPlayerEligibleForDate(player, selectedSession.session_date))}
        attendance={attendance}
        competitions={competitions.filter((competition) => competition.session_id === selectedSession.id)}
        results={results}
        onBack={() => setSelectedSessionId(null)}
        onChange={loadTraining}
      />
    )
  }

  const downloadExcel = () => exportTrainingExcel({ players, sessions, attendance, competitions, results, summary })

  return (
    <main className="page-shell training-shell">
      <section className="training-hero">
        <div>
          <p className="eyebrow">TRAINING DATA</p>
          <h1>Entrenaments</h1>
          <p>Assistència, competicions i classificació acumulada de tota la temporada.</p>
        </div>
        <button className="button primary large" onClick={downloadExcel} disabled={loading}>Descarregar Excel</button>
      </section>

      <nav className="training-tabs">
        <button className={view === 'season' ? 'active' : ''} onClick={() => setView('season')}>Temporada</button>
        <button className={view === 'sessions' ? 'active' : ''} onClick={() => setView('sessions')}>Entrenaments</button>
        <button className={view === 'players' ? 'active' : ''} onClick={() => setView('players')}>Jugadors</button>
      </nav>

      {view === 'season' && <SeasonView summary={summary} sessions={sessions} competitions={competitions} />}
      {view === 'sessions' && (
        <SessionsView
          sessions={sessions}
          attendance={attendance}
          competitions={competitions}
          onOpen={setSelectedSessionId}
          onChange={loadTraining}
        />
      )}
      {view === 'players' && <TrainingPlayersManager players={players} onChange={loadTraining} />}
    </main>
  )
}

function SeasonView({ summary, sessions, competitions }: {
  summary: ReturnType<typeof buildTrainingSummary>
  sessions: TrainingSession[]
  competitions: TrainingCompetition[]
}) {
  const sorted = [...summary].sort((a, b) => a.finalRank - b.finalRank || a.player.name.localeCompare(b.player.name))
  const avgAttendance = summary.length ? summary.reduce((total, row) => total + row.attendancePct, 0) / summary.length : 0

  return (
    <>
      <div className="training-kpis">
        <article><span>Entrenaments</span><strong>{sessions.length}</strong><small>registrats</small></article>
        <article><span>Competicions</span><strong>{competitions.length}</strong><small>total temporada</small></article>
        <article><span>Assistència mitjana</span><strong>{avgAttendance.toFixed(1)}%</strong><small>plantilla</small></article>
        <article className="leader"><span>Líder actual</span><strong>{sorted[0]?.player.name ?? '—'}</strong><small>{sorted[0]?.totalPoints ?? 0} punts</small></article>
      </div>

      <section className="card training-card">
        <div className="section-heading training-section-heading">
          <div><p className="eyebrow">TEMPORADA</p><h2>Classificació</h2></div>
          <span>1r = 4 · 2n = 3 · 3r = 2 · 4t = 1. Els empats comparteixen punts.</span>
        </div>
        <div className="training-table-wrap">
          <table className="training-table">
            <thead><tr><th>#</th><th>Jugador</th><th>Assistència</th><th>%</th><th>Shooting</th><th>Free throws</th><th>Competition</th><th>Total</th></tr></thead>
            <tbody>
              {sorted.map((row) => (
                <tr key={row.player.id} className={row.finalRank <= 3 ? `rank-${row.finalRank}` : ''}>
                  <td><span className="training-rank">{row.finalRank}</span></td>
                  <td><div className="training-player-cell"><span className="jersey">{row.player.jersey_number || '–'}</span><strong>{row.player.name}</strong></div></td>
                  <td>{row.present}/{row.sessions}</td>
                  <td><AttendanceBar pct={row.attendancePct} /></td>
                  <td>{row.shooting}</td>
                  <td>{row.freeThrows}</td>
                  <td>{row.competition}</td>
                  <td><strong className="training-total">{row.totalPoints}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!sorted.length && <p className="empty-inline">Afegeix jugadors a la pestanya Jugadors per començar.</p>}
      </section>
    </>
  )
}

function AttendanceBar({ pct }: { pct: number }) {
  return <div className="training-attendance-bar"><strong>{pct.toFixed(1)}%</strong><span><i style={{ width: `${Math.min(100, pct)}%` }} /></span></div>
}

function SessionsView({ sessions, attendance, competitions, onOpen, onChange }: {
  sessions: TrainingSession[]
  attendance: TrainingAttendance[]
  competitions: TrainingCompetition[]
  onOpen: (id: string) => void
  onChange: () => Promise<void>
}) {
  const [creating, setCreating] = useState(false)

  const removeSession = async (session: TrainingSession) => {
    if (!confirm(`Eliminar l'entrenament del ${session.session_date} i totes les seves dades?`)) return
    const { error } = await supabase.from('training_sessions').delete().eq('id', session.id)
    if (error) return alert(error.message)
    await onChange()
  }

  if (creating) {
    return <NewSession onCancel={() => setCreating(false)} onCreated={async (id) => { setCreating(false); await onChange(); onOpen(id) }} />
  }

  return (
    <section className="card training-card">
      <div className="section-heading training-section-heading">
        <div><p className="eyebrow">SESSIONS</p><h2>Entrenaments</h2></div>
        <button className="button primary" onClick={() => setCreating(true)}>Nou entrenament</button>
      </div>
      <div className="training-session-grid">
        {sessions.map((session) => {
          const present = attendance.filter((item) => item.session_id === session.id && item.present).length
          const count = competitions.filter((competition) => competition.session_id === session.id).length
          return (
            <article className="training-session-card" key={session.id}>
              <button className="training-session-open" onClick={() => onOpen(session.id)}>
                <time>{new Date(`${session.session_date}T12:00:00`).toLocaleDateString('ca-ES', { day: '2-digit', month: 'short' })}</time>
                <span><strong>{session.title}</strong><small>{present} assistents · {count} competicions</small></span>
                <b>→</b>
              </button>
              <button className="training-delete" onClick={() => void removeSession(session)} title="Eliminar">×</button>
            </article>
          )
        })}
        {!sessions.length && <p className="empty-inline">Encara no hi ha entrenaments.</p>}
      </div>
    </section>
  )
}

function NewSession({ onCancel, onCreated }: { onCancel: () => void; onCreated: (id: string) => Promise<void> }) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10))
  const [title, setTitle] = useState('Entrenament')
  const [notes, setNotes] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    setBusy(true)
    const { data, error } = await supabase.from('training_sessions').insert({
      session_date: date,
      title: title.trim() || 'Entrenament',
      notes: notes.trim() || null,
    }).select('*').single()
    setBusy(false)
    if (error || !data) return alert(error?.message ?? 'No s’ha pogut crear l’entrenament.')
    await onCreated(data.id)
  }

  return (
    <section className="card training-card training-new-session">
      <button className="back-link" onClick={onCancel}>← Cancel·lar</button>
      <form onSubmit={submit} className="stack gap-md">
        <div><p className="eyebrow">NOVA SESSIÓ</p><h2>Crear entrenament</h2></div>
        <div className="training-form-grid">
          <label className="field"><span>Data</span><input type="date" value={date} onChange={(event) => setDate(event.target.value)} /></label>
          <label className="field"><span>Nom</span><input value={title} onChange={(event) => setTitle(event.target.value)} /></label>
        </div>
        <label className="field"><span>Notes</span><input value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Opcional" /></label>
        <div className="training-actions"><button type="button" className="button secondary" onClick={onCancel}>Cancel·lar</button><button className="button primary" disabled={busy}>Crear i registrar</button></div>
      </form>
    </section>
  )
}

function TrainingSessionEditor({ session, players, attendance, competitions, results, onBack, onChange }: {
  session: TrainingSession
  players: TrainingPlayer[]
  attendance: TrainingAttendance[]
  competitions: TrainingCompetition[]
  results: CompetitionResult[]
  onBack: () => void
  onChange: () => Promise<void>
}) {
  const [newType, setNewType] = useState<CompetitionType>('shooting')
  const [newName, setNewName] = useState('')
  const presentIds = new Set(attendance.filter((item) => item.session_id === session.id && item.present).map((item) => item.player_id))

  const setAttendance = async (playerId: string, present: boolean) => {
    const { error } = await supabase.from('training_attendance').upsert({
      session_id: session.id,
      player_id: playerId,
      present,
    }, { onConflict: 'session_id,player_id' })
    if (error) return alert(error.message)
    await onChange()
  }

  const markAll = async (present: boolean) => {
    if (!players.length) return
    const { error } = await supabase.from('training_attendance').upsert(
      players.map((player) => ({ session_id: session.id, player_id: player.id, present })),
      { onConflict: 'session_id,player_id' },
    )
    if (error) return alert(error.message)
    await onChange()
  }

  const addCompetition = async (event: FormEvent) => {
    event.preventDefault()
    const sameType = competitions.filter((competition) => competition.competition_type === newType)
    const sequence = Math.max(0, ...sameType.map((competition) => competition.sequence_no)) + 1
    const name = newName.trim() || `${competitionTypeLabel[newType]} ${sequence}`
    const { error } = await supabase.from('training_competitions').insert({
      session_id: session.id,
      competition_type: newType,
      name,
      sequence_no: sequence,
    })
    if (error) return alert(error.message)
    setNewName('')
    await onChange()
  }

  const removeCompetition = async (competition: TrainingCompetition) => {
    if (!confirm(`Eliminar ${competition.name} i els seus resultats?`)) return
    const { error } = await supabase.from('training_competitions').delete().eq('id', competition.id)
    if (error) return alert(error.message)
    await onChange()
  }

  return (
    <main className="page-shell training-shell">
      <button className="back-link" onClick={onBack}>← Tornar als entrenaments</button>
      <div className="page-title-row training-session-title">
        <div><p className="eyebrow">{session.session_date}</p><h1>{session.title}</h1><p className="muted">{session.notes || 'Registra assistència i competicions.'}</p></div>
        <div className="training-present-count"><strong>{presentIds.size}</strong><span>assistents</span></div>
      </div>

      <section className="card training-card">
        <div className="section-heading training-section-heading">
          <div><p className="eyebrow">ASSISTÈNCIA</p><h2>Un toc per jugador</h2></div>
          <div className="training-actions"><button className="button secondary compact" onClick={() => void markAll(true)}>Tots presents</button><button className="button secondary compact" onClick={() => void markAll(false)}>Netejar</button></div>
        </div>
        <div className="training-attendance-grid">
          {players.map((player) => {
            const present = presentIds.has(player.id)
            return (
              <button key={player.id} className={`training-attendance-player ${present ? 'present' : ''}`} onClick={() => void setAttendance(player.id, !present)}>
                <span className="training-check">{present ? '✓' : ''}</span>
                <span className="jersey">{player.jersey_number || '–'}</span>
                <strong>{player.name}</strong>
              </button>
            )
          })}
          {!players.length && <p className="empty-inline">No hi ha jugadors computables per aquesta data.</p>}
        </div>
      </section>

      <section className="card training-card">
        <div className="section-heading training-section-heading">
          <div><p className="eyebrow">COMPETICIONS</p><h2>Resultats del dia</h2></div>
          <span>Pots crear-ne més d'una de cada tipus.</span>
        </div>
        <form className="training-competition-add" onSubmit={addCompetition}>
          <select value={newType} onChange={(event) => setNewType(event.target.value as CompetitionType)}>
            <option value="shooting">Shooting</option>
            <option value="free_throws">Free throws</option>
            <option value="competition">Competition</option>
          </select>
          <input value={newName} onChange={(event) => setNewName(event.target.value)} placeholder="Nom opcional, ex. 5 spots" />
          <button className="button primary">Afegir competició</button>
        </form>

        <div className="training-competition-list">
          {[...competitions].sort((a, b) => a.sequence_no - b.sequence_no).map((competition) => (
            <CompetitionCard
              key={competition.id}
              competition={competition}
              players={players}
              results={results.filter((result) => result.competition_id === competition.id)}
              onChange={onChange}
              onDelete={() => void removeCompetition(competition)}
            />
          ))}
          {!competitions.length && <p className="empty-inline">Encara no hi ha competicions en aquest entrenament.</p>}
        </div>
      </section>
    </main>
  )
}

function CompetitionCard({ competition, players, results, onChange, onDelete }: {
  competition: TrainingCompetition
  players: TrainingPlayer[]
  results: CompetitionResult[]
  onChange: () => Promise<void>
  onDelete: () => void
}) {
  const resultByPlayer = new Map(results.map((result) => [result.player_id, result]))

  const setPlace = async (playerId: string, place: 1 | 2 | 3 | 4) => {
    const current = resultByPlayer.get(playerId)
    if (current?.place === place) {
      const { error } = await supabase.from('training_competition_results').delete().eq('competition_id', competition.id).eq('player_id', playerId)
      if (error) return alert(error.message)
    } else {
      const { error } = await supabase.from('training_competition_results').upsert({
        competition_id: competition.id,
        player_id: playerId,
        place,
        points: pointsForPlace(place),
      }, { onConflict: 'competition_id,player_id' })
      if (error) return alert(error.message)
    }
    await onChange()
  }

  return (
    <article className="training-competition-card">
      <header>
        <div><span className={`training-type ${competition.competition_type}`}>{competitionTypeLabel[competition.competition_type]}</span><h3>{competition.name}</h3></div>
        <button className="training-delete" onClick={onDelete}>×</button>
      </header>
      <div className="training-place-grid">
        {([1, 2, 3, 4] as const).map((place) => (
          <section key={place} className={`training-place place-${place}`}>
            <div className="training-place-title"><strong>{{1: '1r', 2: '2n', 3: '3r', 4: '4t'}[place]}</strong><span>+{pointsForPlace(place)} pts</span></div>
            <div className="training-place-players">
              {players.map((player) => (
                <button key={player.id} className={resultByPlayer.get(player.id)?.place === place ? 'selected' : ''} onClick={() => void setPlace(player.id, place)}>
                  <span>#{player.jersey_number || '–'}</span>{player.name}
                </button>
              ))}
            </div>
          </section>
        ))}
      </div>
      <footer>
        {[...results].sort((a, b) => a.place - b.place).map((result) => (
          <span key={result.id}><strong>{result.place}.</strong> {players.find((player) => player.id === result.player_id)?.name ?? 'Jugador'} <b>+{result.points}</b></span>
        ))}
        {!results.length && <small>Encara no hi ha resultats.</small>}
      </footer>
    </article>
  )
}
