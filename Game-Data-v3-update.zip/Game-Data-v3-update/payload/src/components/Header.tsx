import { supabase } from '../lib/supabase'

type AppSection = 'games' | 'training'

interface HeaderProps {
  onHome: () => void
  section?: AppSection
  onSectionChange?: (section: AppSection) => void
}

export function Header({ onHome, section = 'games', onSectionChange }: HeaderProps) {
  return (
    <header className="app-header">
      <button className="brand-button" onClick={onHome} aria-label="Anar als partits">
        <img src="/kids-us-manresa.png" alt="" />
        <div>
          <strong>Kids&Us Manresa</strong>
          <span>Game Data</span>
        </div>
      </button>

      {onSectionChange && (
        <nav className="module-nav" aria-label="Seccions de l'app">
          <button className={section === 'games' ? 'active' : ''} onClick={() => onSectionChange('games')}>Partits</button>
          <button className={section === 'training' ? 'active' : ''} onClick={() => onSectionChange('training')}>Entrenaments</button>
        </nav>
      )}

      <div className="header-actions">
        <span className="header-context">{section === 'games' ? 'Seguiment de partits' : 'Training Data'}</span>
        <button className="button ghost compact" onClick={() => supabase.auth.signOut()}>
          Tancar sessió
        </button>
      </div>
    </header>
  )
}
