#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / 'payload'

REQUIRED = [
    ROOT / 'src' / 'App.tsx',
    ROOT / 'src' / 'components' / 'MatchConsole.tsx',
    ROOT / 'src' / 'components' / 'Header.tsx',
    ROOT / 'src' / 'components' / 'Login.tsx',
    ROOT / 'src' / 'lib' / 'game.ts',
    ROOT / 'src' / 'types.ts',
    ROOT / 'src' / 'main.tsx',
    ROOT / 'package.json',
    ROOT / 'supabase' / 'schema.sql',
]

missing = [str(path.relative_to(ROOT)) for path in REQUIRED if not path.exists()]
if missing:
    print('ERROR: aquesta no sembla la carpeta original de JEscarre/Game-Data.')
    print('Falten:', ', '.join(missing))
    sys.exit(1)

# Guard against applying to the previously rebuilt/non-original project.
login = (ROOT / 'src/components/Login.tsx').read_text(encoding='utf-8')
if 'VITE_LOGIN_EMAIL' not in login or 'Contrasenya' not in login:
    print('ERROR: el Login.tsx no correspon a la versió original amb contrasenya única.')
    sys.exit(1)

backup = ROOT / '_backup_abans_training_v3'
if not backup.exists():
    for relative in [
        'src/App.tsx', 'src/components/Header.tsx', 'src/components/MatchConsole.tsx',
        'src/lib/game.ts', 'src/types.ts', 'src/main.tsx', 'package.json'
    ]:
        src = ROOT / relative
        dst = backup / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    print(f'Backup creat a {backup.name}/')

# 1) Preserve MatchConsole, changing only 1-minute -> 30-second step.
match_path = ROOT / 'src/components/MatchConsole.tsx'
match = match_path.read_text(encoding='utf-8')
replacements = [
    ('  nextWholeMinute,', '  nextThirtySeconds,'),
    ('  const nextMinute = nextWholeMinute(game.current_clock_seconds)', '  const nextStep = nextThirtySeconds(game.current_clock_seconds)'),
    ("  const confirmNextMinute = async () => {\n    if (game.current_clock_seconds === 0) return\n    await updateClock(game.current_period, nextMinute, true, 'minute')\n  }",
     "  const confirmNextThirtySeconds = async () => {\n    if (game.current_clock_seconds === 0) return\n    await updateClock(game.current_period, nextStep, true, '30_seconds')\n  }"),
    ('<button className="minute-button" onClick={confirmNextMinute} disabled={game.current_clock_seconds === 0 || isFinished}>\n            <span>PASSAR AL SEGÜENT MINUT</span>\n            <strong>{formatClock(game.current_clock_seconds)} → {formatClock(nextMinute)}</strong>\n          </button>',
     '<button className="minute-button" onClick={confirmNextThirtySeconds} disabled={game.current_clock_seconds === 0 || isFinished}>\n            <span>PASSAR 30 SEGONS</span>\n            <strong>{formatClock(game.current_clock_seconds)} → {formatClock(nextStep)}</strong>\n          </button>'),
]
for old, new in replacements:
    if old not in match and new not in match:
        print('ERROR: no he trobat un bloc esperat a MatchConsole.tsx. No aplico una modificació parcial.')
        sys.exit(1)
    match = match.replace(old, new)
match_path.write_text(match, encoding='utf-8')

# 2) Preserve game helpers, changing only the step helper.
game_path = ROOT / 'src/lib/game.ts'
game = game_path.read_text(encoding='utf-8')
old_helper = """export const nextWholeMinute = (clockSeconds: number) => {\n  if (clockSeconds <= 0) return 0\n  if (clockSeconds % 60 === 0) return Math.max(0, clockSeconds - 60)\n  return Math.floor(clockSeconds / 60) * 60\n}"""
new_helper = """export const nextThirtySeconds = (clockSeconds: number) => {\n  if (clockSeconds <= 0) return 0\n  const remainder = clockSeconds % 30\n  if (remainder === 0) return Math.max(0, clockSeconds - 30)\n  return Math.max(0, clockSeconds - remainder)\n}"""
if old_helper not in game and new_helper not in game:
    print('ERROR: no he trobat nextWholeMinute a src/lib/game.ts.')
    sys.exit(1)
game_path.write_text(game.replace(old_helper, new_helper), encoding='utf-8')

# 3) Add training types without altering existing game types.
types_path = ROOT / 'src/types.ts'
types = types_path.read_text(encoding='utf-8')
training_types = r'''

// Training Data v3
export interface TrainingPlayer {
  id: string
  name: string
  jersey_number: string
  joined_on: string
  left_on: string | null
  active: boolean
  created_at: string
}

export interface TrainingSession {
  id: string
  session_date: string
  title: string
  notes: string | null
  created_at: string
}

export interface TrainingAttendance {
  id: string
  session_id: string
  player_id: string
  present: boolean
  created_at: string
}

export type CompetitionType = 'shooting' | 'free_throws' | 'competition'

export interface TrainingCompetition {
  id: string
  session_id: string
  competition_type: CompetitionType
  name: string
  sequence_no: number
  created_at: string
}

export interface CompetitionResult {
  id: string
  competition_id: string
  player_id: string
  place: 1 | 2 | 3 | 4
  points: number
  created_at: string
}

export interface PlayerTrainingSummary {
  player: TrainingPlayer
  sessions: number
  present: number
  attendancePct: number
  shooting: number
  freeThrows: number
  competition: number
  totalPoints: number
  finalRank: number
}
'''
if 'export interface TrainingPlayer' not in types:
    types_path.write_text(types.rstrip() + training_types + '\n', encoding='utf-8')

# 4) Keep original styles.css untouched; import a supplementary stylesheet.
main_path = ROOT / 'src/main.tsx'
main = main_path.read_text(encoding='utf-8')
if "import './training.css'" not in main:
    marker = "import './styles.css'"
    if marker not in main:
        print('ERROR: no he trobat la importació original de styles.css.')
        sys.exit(1)
    main = main.replace(marker, marker + "\nimport './training.css'")
    main_path.write_text(main, encoding='utf-8')

# 5) App/Header + new training files + migration.
copy_map = {
    'src/App.tsx': 'src/App.tsx',
    'src/components/Header.tsx': 'src/components/Header.tsx',
    'src/components/TrainingDashboard.tsx': 'src/components/TrainingDashboard.tsx',
    'src/components/TrainingPlayersManager.tsx': 'src/components/TrainingPlayersManager.tsx',
    'src/lib/training.ts': 'src/lib/training.ts',
    'src/lib/exportTrainingExcel.ts': 'src/lib/exportTrainingExcel.ts',
    'src/training.css': 'src/training.css',
    'supabase/migration_training_v3.sql': 'supabase/migration_training_v3.sql',
}
for source_rel, target_rel in copy_map.items():
    source = PAYLOAD / source_rel
    target = ROOT / target_rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)

# 6) Add Excel library. npm install will refresh package-lock.json.
package_path = ROOT / 'package.json'
package = json.loads(package_path.read_text(encoding='utf-8'))
package['version'] = '3.0.0'
package.setdefault('dependencies', {})['xlsx'] = '^0.18.5'
package_path.write_text(json.dumps(package, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

print('')
print('✅ Actualització Training Data v3 aplicada sobre la carpeta ORIGINAL.')
print('✅ Login original amb una sola contrasenya: preservat.')
print('✅ styles.css original: preservat; els estils nous són a training.css.')
print('✅ MatchConsole original: només s’ha canviat el pas d’1:00 a 0:30.')
print('✅ Supabase de partits: no s’ha modificat.')
print('')
print('Següent: npm install')
print('Després executa supabase/migration_training_v3.sql UNA VEGADA a Supabase.')
print('Finalment: npm run dev')
