-- Kids&Us Manresa · Game Data · Training Data v3
-- MIGRACIÓ SEGURA sobre l'esquema v2 existent.
-- No modifica ni elimina games, game_players ni game_events.
-- Executa aquest fitxer UNA SOLA VEGADA a Supabase > SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.training_players (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(trim(name)) > 0),
  jersey_number text not null default '',
  joined_on date not null default current_date,
  left_on date,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  check (left_on is null or left_on >= joined_on)
);

create table if not exists public.training_sessions (
  id uuid primary key default gen_random_uuid(),
  session_date date not null,
  title text not null default 'Entrenament' check (length(trim(title)) > 0),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.training_attendance (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.training_sessions(id) on delete cascade,
  player_id uuid not null references public.training_players(id) on delete cascade,
  present boolean not null default false,
  created_at timestamptz not null default now(),
  unique(session_id, player_id)
);

create table if not exists public.training_competitions (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.training_sessions(id) on delete cascade,
  competition_type text not null check (competition_type in ('shooting', 'free_throws', 'competition')),
  name text not null check (length(trim(name)) > 0),
  sequence_no integer not null default 1 check (sequence_no >= 1),
  created_at timestamptz not null default now()
);

create table if not exists public.training_competition_results (
  id uuid primary key default gen_random_uuid(),
  competition_id uuid not null references public.training_competitions(id) on delete cascade,
  player_id uuid not null references public.training_players(id) on delete cascade,
  place integer not null check (place between 1 and 4),
  points integer not null check (points between 1 and 4),
  created_at timestamptz not null default now(),
  unique(competition_id, player_id),
  check (
    (place = 1 and points = 4) or
    (place = 2 and points = 3) or
    (place = 3 and points = 2) or
    (place = 4 and points = 1)
  )
);

create index if not exists idx_training_sessions_date on public.training_sessions(session_date desc);
create index if not exists idx_training_attendance_session on public.training_attendance(session_id, player_id);
create index if not exists idx_training_competitions_session on public.training_competitions(session_id, competition_type, sequence_no);
create index if not exists idx_training_results_competition on public.training_competition_results(competition_id, player_id);

alter table public.training_players enable row level security;
alter table public.training_sessions enable row level security;
alter table public.training_attendance enable row level security;
alter table public.training_competitions enable row level security;
alter table public.training_competition_results enable row level security;

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'training_players',
    'training_sessions',
    'training_attendance',
    'training_competitions',
    'training_competition_results'
  ]
  loop
    execute format('drop policy if exists authenticated_all on public.%I', table_name);
    execute format(
      'create policy authenticated_all on public.%I for all to authenticated using (true) with check (true)',
      table_name
    );
  end loop;
end $$;

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'training_players',
    'training_sessions',
    'training_attendance',
    'training_competitions',
    'training_competition_results'
  ]
  loop
    if not exists (
      select 1
      from pg_publication_tables
      where pubname = 'supabase_realtime'
        and schemaname = 'public'
        and tablename = table_name
    ) then
      execute format('alter publication supabase_realtime add table public.%I', table_name);
    end if;
  end loop;
end $$;
