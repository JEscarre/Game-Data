#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/Desktop/Game-Data-v3"

if [ -e "$TARGET" ]; then
  echo "Ja existeix $TARGET"
  echo "Elimina-la o canvia-li el nom abans de tornar a executar aquest script."
  exit 1
fi

echo "Clonant el repositori original de GitHub..."
git clone https://github.com/JEscarre/Game-Data.git "$TARGET"
cd "$TARGET"
python3 "$SCRIPT_DIR/apply_update.py"

echo ""
echo "Instal·lant dependències..."
npm install

echo ""
echo "✅ Carpeta completa preparada a: $TARGET"
echo "Abans d'obrir Entrenaments, executa supabase/migration_training_v3.sql a Supabase."
echo "Després, dins la carpeta: npm run dev"
