# Validació tècnica

- L'actualitzador comprova que el projecte base sigui la versió original amb `VITE_LOGIN_EMAIL` i login només amb contrasenya.
- Abans de tocar res crea `_backup_abans_training_v3/` amb els fitxers modificats.
- `MatchConsole.tsx` només es modifica mitjançant reemplaçaments exactes del pas de minut a pas de 30 segons.
- `src/styles.css` original no es reemplaça; `src/training.css` només afegeix estils nous i reforça visualment el comptador de faltes existent.
- La migració SQL només crea taules `training_*`; no fa `alter`, `drop`, `delete` ni `update` sobre `games`, `game_players` o `game_events`.
- Comprovació TypeScript dels nous components i llibreries superada amb stubs de dependències externes.
- Proves de lògica superades: puntuació 4-3-2-1, empats i elegibilitat d'assistència des de `joined_on`.
